﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WEEK_11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server =localhost;" + "uid =student;" + "pwd=isbmantap;" + "database=premier_league");
            sqlConnect.Open();
            sqlConnect.Close();
            /*
            string query = "Select m.match_id, m.match_date, t.team_name as `Team Home`, t2.team_name as `Team Away`, m.goal_home, m.goal_away, r.referee_name from `match` m, team t, team t2, referee r where m.team_home = t.team_id and m.team_away = t2.team_id and m.referee_id = r.referee_id;";
            */
            string query = "Select t.team_id, t.team_name, t.home_stadium, t.capacity, t.city, m.manager_name as `Manager Name`, m2.manager_name as `Assistant Manager Name`, p.player_name as `Captain Name` from team t, manager m, manager m2, player p where m.manager_id = t.manager_id and m2.manager_id = t.assmanager_id and p.player_id = t.captain_id;";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            DataTable team = new DataTable();
            sqlDataAdapter.Fill(team);
            dgv.DataSource = team;
        }
    }
}
