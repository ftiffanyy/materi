﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtteam; DataTable dtplayer; DataTable dmatch; DataTable type;
        string query;
        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server =localhost;" + "uid =student;" + "pwd=isbmantap;" + "database=premier_league");
            dtteam = new DataTable();
            query = "select team_id, team_name from team";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteam);
            cb_team.DataSource = dtteam;
            cb_team.DisplayMember = "team_name";
            cb_team.ValueMember = "team_id";
            cb_team.SelectedIndex = -1;

            type = new DataTable();
            type.Columns.Add("Type ID");
            type.Columns.Add("Type Name");
            type.Rows.Add("GO","Goal");
            type.Rows.Add("GP", "Goal Penalty");
            type.Rows.Add("GW", "Own Goal");
            type.Rows.Add("CY", "Yellow Card");
            type.Rows.Add("CR", "Red Card");
            type.Rows.Add("PM", "Penalty Miss");
            cb_type.DataSource = type;
            cb_type.DisplayMember = "Type Name";
            cb_type.ValueMember = "Type ID";

        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtplayer = new DataTable();
            query = $"select player_id, player_name from player where team_id = '{cb_team.SelectedValue}'";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtplayer);
            cb_player.DataSource = dtplayer;
            cb_player.DisplayMember = "player_name";
            cb_player.ValueMember = "player_id";
        }

        private void bt_add_Click(object sender, EventArgs e)
        {
            dmatch.Rows.Add(tb_mnt.Text, cb_team.SelectedValue, cb_player.SelectedValue, cb_type.SelectedValue);
            dgv.DataSource = dmatch;
        }

        private void cb_player_SelectedIndexChanged(object sender, EventArgs e)
        {
            dmatch = new DataTable();
            query = $"select minute, team_id as `Team ID`, player_id as `Player ID`, type from dmatch where player_id = '{cb_player.SelectedValue}'";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dmatch);
            dgv.DataSource = dmatch;
        }
    }
}
