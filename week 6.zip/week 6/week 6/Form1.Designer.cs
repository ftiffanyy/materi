﻿namespace week_6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_add = new System.Windows.Forms.Button();
            this.tb_input = new System.Windows.Forms.TextBox();
            this.bt_send = new System.Windows.Forms.Button();
            this.lb_angka = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.data_makanan = new System.Windows.Forms.DataGridView();
            this.bt_remove = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.data_makanan)).BeginInit();
            this.SuspendLayout();
            // 
            // bt_add
            // 
            this.bt_add.Location = new System.Drawing.Point(45, 498);
            this.bt_add.Name = "bt_add";
            this.bt_add.Size = new System.Drawing.Size(150, 57);
            this.bt_add.TabIndex = 0;
            this.bt_add.Text = "ADD";
            this.bt_add.UseVisualStyleBackColor = true;
            this.bt_add.Click += new System.EventHandler(this.bt_open_Click);
            // 
            // tb_input
            // 
            this.tb_input.Location = new System.Drawing.Point(1084, 121);
            this.tb_input.Name = "tb_input";
            this.tb_input.Size = new System.Drawing.Size(168, 31);
            this.tb_input.TabIndex = 1;
            // 
            // bt_send
            // 
            this.bt_send.Location = new System.Drawing.Point(1106, 176);
            this.bt_send.Name = "bt_send";
            this.bt_send.Size = new System.Drawing.Size(128, 47);
            this.bt_send.TabIndex = 2;
            this.bt_send.Text = "send";
            this.bt_send.UseVisualStyleBackColor = true;
            this.bt_send.Click += new System.EventHandler(this.bt_send_Click);
            // 
            // lb_angka
            // 
            this.lb_angka.AutoSize = true;
            this.lb_angka.Location = new System.Drawing.Point(1129, 399);
            this.lb_angka.Name = "lb_angka";
            this.lb_angka.Size = new System.Drawing.Size(70, 25);
            this.lb_angka.TabIndex = 3;
            this.lb_angka.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1002, 311);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(337, 42);
            this.label1.TabIndex = 4;
            this.label1.Text = "ANGKA RANDOM";
            // 
            // data_makanan
            // 
            this.data_makanan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data_makanan.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.data_makanan.Location = new System.Drawing.Point(45, 26);
            this.data_makanan.MultiSelect = false;
            this.data_makanan.Name = "data_makanan";
            this.data_makanan.RowHeadersWidth = 82;
            this.data_makanan.RowTemplate.Height = 33;
            this.data_makanan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.data_makanan.Size = new System.Drawing.Size(780, 451);
            this.data_makanan.TabIndex = 5;
            // 
            // bt_remove
            // 
            this.bt_remove.Location = new System.Drawing.Point(224, 498);
            this.bt_remove.Name = "bt_remove";
            this.bt_remove.Size = new System.Drawing.Size(150, 57);
            this.bt_remove.TabIndex = 6;
            this.bt_remove.Text = "REMOVE";
            this.bt_remove.UseVisualStyleBackColor = true;
            this.bt_remove.Click += new System.EventHandler(this.bt_remove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 620);
            this.Controls.Add(this.bt_remove);
            this.Controls.Add(this.data_makanan);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_angka);
            this.Controls.Add(this.bt_send);
            this.Controls.Add(this.tb_input);
            this.Controls.Add(this.bt_add);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.data_makanan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_add;
        private System.Windows.Forms.TextBox tb_input;
        private System.Windows.Forms.Button bt_send;
        private System.Windows.Forms.Label lb_angka;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView data_makanan;
        private System.Windows.Forms.Button bt_remove;
    }
}

