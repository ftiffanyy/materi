﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_6
{
    public partial class Form1 : Form
    {
        Form2 frm; Form3 form;
        DataTable dtmenu;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtmenu = new DataTable();
            dtmenu.Columns.Add("ID Makanan");
            dtmenu.Columns.Add("Nama Produk");
            dtmenu.Columns.Add("Harga");
            dtmenu.Rows.Add("001", "Nasi Goreng", "25000");
            dtmenu.Rows.Add("002", "Ayam Goreng", "20000");
            dtmenu.Rows.Add("003", "Ayam Geprek", "22000");
            dtmenu.Rows.Add("004", "Nasi Ayam Sayur", "15000");
            dtmenu.Rows.Add("005", "Es Teh Manis", "5000");
            data_makanan.DataSource = dtmenu;
        }

        private void bt_open_Click(object sender, EventArgs e)
        {
            frm = new Form2(this);
            frm.Show(); 
            //frm.ShowDialog(); //user harus mengisi terlebih dahulu
        }

        private void bt_send_Click(object sender, EventArgs e)
        {
            frm.Setlabel(tb_input.Text);
        }
        public void SetAngkaRandom(int s)
        {
            lb_angka.Text = s.ToString();
        }
        public void AddMenu (string x, string y, string z)
        {
            dtmenu.Rows.Add (x, y, z);
            data_makanan.DataSource = dtmenu;
        }

        private void bt_remove_Click(object sender, EventArgs e)
        {
            form = new Form3(this, dtmenu);
            form.Show();
        }
        public void Remove(int x)
        {
            dtmenu.Rows.RemoveAt(x);
            data_makanan.DataSource = dtmenu;
        }
    }
}
