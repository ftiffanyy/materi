﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_6
{
    public partial class Form2 : Form
    {
        Form1 form;
        public Form2()
        {
            InitializeComponent();
        }
        public Form2(Form _sender)
        {
            InitializeComponent();
            form = (Form1)_sender;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        public void Setlabel(string s)
        {
            lbl_input.Text = s;
        }

        private void bt_random_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int angka = rnd.Next(0, 50);
            form.SetAngkaRandom(angka);
        }

        private void bt_addmenu_Click(object sender, EventArgs e)
        {
            form.AddMenu(tb_id.Text, tb_nama.Text, tb_harga.Text);
        }
    }
}
