﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_6
{
    public partial class Form3 : Form
    {
        Form1 form;
        DataTable dt;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
           
        }
        public Form3(Form _sender, DataTable dtmenu)
        {
            InitializeComponent();
            form = (Form1)_sender;
            dt = dtmenu;
            cb_menu.DataSource = dt;
            cb_menu.DisplayMember = "Nama Produk";
            tb_id.Enabled = false;
            tb_harga.Enabled = false;
        }

        private void bt_removemenu_Click(object sender, EventArgs e)
        {
            form.Remove(Convert.ToInt32(cb_menu.SelectedIndex));
            tb_id.Text = dt.Rows[cb_menu.SelectedIndex][0].ToString();
            tb_harga.Text = dt.Rows[cb_menu.SelectedIndex][2].ToString();
        }

        private void cb_menu_SelectedIndexChanged(object sender, EventArgs e)
        {
            tb_id.Text = dt.Rows[cb_menu.SelectedIndex][0].ToString();
            tb_harga.Text = dt.Rows[cb_menu.SelectedIndex][2].ToString();
        }
    }
}
