﻿namespace week_6
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_input = new System.Windows.Forms.Label();
            this.bt_random = new System.Windows.Forms.Button();
            this.bt_addmenu = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_id = new System.Windows.Forms.TextBox();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.tb_harga = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_input
            // 
            this.lbl_input.AutoSize = true;
            this.lbl_input.Location = new System.Drawing.Point(1101, 251);
            this.lbl_input.Name = "lbl_input";
            this.lbl_input.Size = new System.Drawing.Size(70, 25);
            this.lbl_input.TabIndex = 0;
            this.lbl_input.Text = "label1";
            // 
            // bt_random
            // 
            this.bt_random.Location = new System.Drawing.Point(1039, 452);
            this.bt_random.Name = "bt_random";
            this.bt_random.Size = new System.Drawing.Size(116, 51);
            this.bt_random.TabIndex = 1;
            this.bt_random.Text = "random";
            this.bt_random.UseVisualStyleBackColor = true;
            this.bt_random.Click += new System.EventHandler(this.bt_random_Click);
            // 
            // bt_addmenu
            // 
            this.bt_addmenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_addmenu.Location = new System.Drawing.Point(230, 214);
            this.bt_addmenu.Name = "bt_addmenu";
            this.bt_addmenu.Size = new System.Drawing.Size(128, 52);
            this.bt_addmenu.TabIndex = 2;
            this.bt_addmenu.Text = "Add";
            this.bt_addmenu.UseVisualStyleBackColor = true;
            this.bt_addmenu.Click += new System.EventHandler(this.bt_addmenu_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(78, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "ID Produk :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nama Produk :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(114, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Harga :";
            // 
            // tb_id
            // 
            this.tb_id.Location = new System.Drawing.Point(230, 44);
            this.tb_id.Name = "tb_id";
            this.tb_id.Size = new System.Drawing.Size(175, 31);
            this.tb_id.TabIndex = 6;
            // 
            // tb_nama
            // 
            this.tb_nama.Location = new System.Drawing.Point(230, 91);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(173, 31);
            this.tb_nama.TabIndex = 7;
            // 
            // tb_harga
            // 
            this.tb_harga.Location = new System.Drawing.Point(230, 147);
            this.tb_harga.Name = "tb_harga";
            this.tb_harga.Size = new System.Drawing.Size(173, 31);
            this.tb_harga.TabIndex = 8;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 330);
            this.Controls.Add(this.tb_harga);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.tb_id);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bt_addmenu);
            this.Controls.Add(this.bt_random);
            this.Controls.Add(this.lbl_input);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_input;
        private System.Windows.Forms.Button bt_random;
        private System.Windows.Forms.Button bt_addmenu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_id;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.TextBox tb_harga;
    }
}