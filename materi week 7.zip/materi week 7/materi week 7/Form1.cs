﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace materi_week_7
{
    public partial class Form1 : Form
    {
        string[] hewanbuas = {"badak", "banteng", "beruang", "buaya", "elang", "gajah", "harimau", "hipopotamus", "hiu", "komodo", "panda", "rubah", "serigala", "singa", "ular"};
        string[] hewanpeliharaan = { "anjing", "ayam", "babi", "bebek", "burung", "domba", "hamster", "kambing", "kelinci", "kucing", "kurakura", "landak", "nemo", "sapi", "sugarglider" };
        string[] fotobebas = { "kevin", "tidur", "valen"};
        int hitung = 0; int buas = 0; int change = 1; int bebas = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string isi = "Y:\\hewan\\" + hewanpeliharaan[0] + ".jpg";
            pb_hewan.Image = new Bitmap(isi);
        }

        private void bt_image_Click(object sender, EventArgs e)
        {
            //pb_hewan.Image = new Bitmap("Y:\\hewan\\hi\\kevin.jpg");
            //string coba = "Y:\\hewan\\hi\\kevin.jpg";
            //pb_hewan.Image = new Bitmap(coba);
        }

        private void bt_next_Click(object sender, EventArgs e)
        {
            if (change == 1)
            {
                if (hitung == 14)
                {

                }
                else
                {
                    hitung += 1;
                }
                string isi = "Y:\\hewan\\" + hewanpeliharaan[hitung] + ".jpg";
                pb_hewan.Image = new Bitmap(isi);
            }
            else if (change == 2)
            {
                if (buas == 14)
                {

                }
                else
                {
                    buas += 1;
                }
                string isi = "Y:\\hewan\\buas\\" + hewanbuas[buas] + ".jpg";
                pb_hewan.Image = new Bitmap(isi);
            }
            else if (change == 3)
            {
                if (bebas == 2)
                {

                }
                else
                {
                    bebas += 1;
                }
                string isi = "Y:\\hewan\\hi\\" + fotobebas[bebas] + ".jpg";
                pb_hewan.Image = new Bitmap(isi);
            }
        }

        private void bt_back_Click(object sender, EventArgs e)
        {
            if (change == 1)
            {
                if (hitung == 0)
                {

                }
                else
                {
                    hitung -= 1;
                }
                string isi = "Y:\\hewan\\" + hewanpeliharaan[hitung] + ".jpg";
                pb_hewan.Image = new Bitmap(isi);
            }
            else if (change == 2)
            {
                if (buas == 0)
                {

                }
                else
                {
                    buas -= 1;
                }
                string isi = "Y:\\hewan\\buas\\" + hewanbuas[buas] + ".jpg";
                pb_hewan.Image = new Bitmap(isi);
            }
            else if (change == 3)
            {
                if (bebas == 0)
                {

                }
                else
                {
                    bebas -= 1;
                }
                string isi = "Y:\\hewan\\hi\\" + fotobebas[bebas] + ".jpg";
                pb_hewan.Image = new Bitmap(isi);
            }
        }

        private void bt_change_Click(object sender, EventArgs e)
        {
            if (change == 1)
            {
                change = 2;
                string isi = "Y:\\hewan\\buas\\" + hewanbuas[buas] + ".jpg";
                pb_hewan.Image = new Bitmap(isi);

            }
            else if (change == 2)
            {
                change = 3;
                string isi = "Y:\\hewan\\hi\\" + fotobebas[bebas] + ".jpg";
                pb_hewan.Image = new Bitmap(isi);
            }
            else if (change == 3)
            {
                change = 1;
                string isi = "Y:\\hewan\\" + hewanpeliharaan[hitung] + ".jpg";
                pb_hewan.Image = new Bitmap(isi);
            }
        }
    }
}
