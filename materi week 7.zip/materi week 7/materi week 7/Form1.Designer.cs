﻿namespace materi_week_7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pb_hewan = new System.Windows.Forms.PictureBox();
            this.bt_change = new System.Windows.Forms.Button();
            this.bt_next = new System.Windows.Forms.Button();
            this.bt_back = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pb_hewan)).BeginInit();
            this.SuspendLayout();
            // 
            // pb_hewan
            // 
            this.pb_hewan.Location = new System.Drawing.Point(333, 147);
            this.pb_hewan.Name = "pb_hewan";
            this.pb_hewan.Size = new System.Drawing.Size(690, 477);
            this.pb_hewan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_hewan.TabIndex = 0;
            this.pb_hewan.TabStop = false;
            // 
            // bt_change
            // 
            this.bt_change.Location = new System.Drawing.Point(65, 38);
            this.bt_change.Name = "bt_change";
            this.bt_change.Size = new System.Drawing.Size(128, 47);
            this.bt_change.TabIndex = 1;
            this.bt_change.Text = "CHANGE";
            this.bt_change.UseVisualStyleBackColor = true;
            this.bt_change.Click += new System.EventHandler(this.bt_change_Click);
            // 
            // bt_next
            // 
            this.bt_next.Location = new System.Drawing.Point(1188, 366);
            this.bt_next.Name = "bt_next";
            this.bt_next.Size = new System.Drawing.Size(128, 47);
            this.bt_next.TabIndex = 2;
            this.bt_next.Text = "NEXT";
            this.bt_next.UseVisualStyleBackColor = true;
            this.bt_next.Click += new System.EventHandler(this.bt_next_Click);
            // 
            // bt_back
            // 
            this.bt_back.Location = new System.Drawing.Point(79, 366);
            this.bt_back.Name = "bt_back";
            this.bt_back.Size = new System.Drawing.Size(128, 47);
            this.bt_back.TabIndex = 3;
            this.bt_back.Text = "BACK";
            this.bt_back.UseVisualStyleBackColor = true;
            this.bt_back.Click += new System.EventHandler(this.bt_back_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(652, 717);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(128, 47);
            this.button4.TabIndex = 4;
            this.button4.Text = "CHANGE";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1410, 805);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.bt_back);
            this.Controls.Add(this.bt_next);
            this.Controls.Add(this.bt_change);
            this.Controls.Add(this.pb_hewan);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb_hewan)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_hewan;
        private System.Windows.Forms.Button bt_change;
        private System.Windows.Forms.Button bt_next;
        private System.Windows.Forms.Button bt_back;
        private System.Windows.Forms.Button button4;
    }
}

