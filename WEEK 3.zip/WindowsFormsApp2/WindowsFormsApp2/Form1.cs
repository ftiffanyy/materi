﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        DataTable dtmakan = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            dtmakan.Columns.Add("ID Makanan");
            dtmakan.Columns.Add("Nama Makanan");
            dtmakan.Columns.Add("Harga Makanan");
            dtmakan.Rows.Add("A001", "Ayam Goreng", "20000");
            dtmakan.Rows.Add("A002", "Bebek Goreng", "25000");
            dtmakan.Rows.Add("A003", "Nasi Goreng", "30000");
            dtmakan.Rows.Add("A004", "Mie Goreng", "10000");
            dtmakan.Rows.Add("A005", "Roti Goreng", "15000");

            lb_makanan.DataSource = dtmakan;
            lb_makanan.ValueMember = "Nama Makanan";
            lb_makanan.DisplayMember = "ID Makanan";
        }

        private void bt_add_Click(object sender, EventArgs e)
        {
            lb_makanan.Items.Add(tb_makan.Text);
        }

        private void bt_clear_Click(object sender, EventArgs e)
        {
            lb_makanan.Items.Clear();
        }

        private void bt_remove_Click(object sender, EventArgs e)
        {
            int index = lb_makanan.SelectedIndex;
            lb_makanan.Items.RemoveAt(index);
        }

        private void bt_pilih_Click(object sender, EventArgs e)
        {
            int choose = lb_makanan.SelectedIndex;
            MessageBox.Show(dtmakan.Rows[choose][0].ToString() + " - " + lb_makanan.SelectedValue + " - Rp. " + dtmakan.Rows[choose][2]);
        }
    }
}
