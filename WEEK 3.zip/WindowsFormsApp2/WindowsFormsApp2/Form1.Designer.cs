﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_makanan = new System.Windows.Forms.ListBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_add = new System.Windows.Forms.Button();
            this.tb_makan = new System.Windows.Forms.TextBox();
            this.bt_clear = new System.Windows.Forms.Button();
            this.bt_remove = new System.Windows.Forms.Button();
            this.bt_pilih = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_makanan
            // 
            this.lb_makanan.FormattingEnabled = true;
            this.lb_makanan.Location = new System.Drawing.Point(15, 90);
            this.lb_makanan.Name = "lb_makanan";
            this.lb_makanan.Size = new System.Drawing.Size(120, 95);
            this.lb_makanan.TabIndex = 0;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Raburi",
            "Madame Liy",
            "Luciole",
            "Pig Daddy",
            "Dapur Farah"});
            this.comboBox1.Location = new System.Drawing.Point(446, 71);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nama Makanan :";
            // 
            // bt_add
            // 
            this.bt_add.Location = new System.Drawing.Point(107, 51);
            this.bt_add.Name = "bt_add";
            this.bt_add.Size = new System.Drawing.Size(75, 23);
            this.bt_add.TabIndex = 3;
            this.bt_add.Text = "Add";
            this.bt_add.UseVisualStyleBackColor = true;
            this.bt_add.Click += new System.EventHandler(this.bt_add_Click);
            // 
            // tb_makan
            // 
            this.tb_makan.Location = new System.Drawing.Point(107, 21);
            this.tb_makan.Name = "tb_makan";
            this.tb_makan.Size = new System.Drawing.Size(100, 20);
            this.tb_makan.TabIndex = 4;
            // 
            // bt_clear
            // 
            this.bt_clear.Location = new System.Drawing.Point(15, 191);
            this.bt_clear.Name = "bt_clear";
            this.bt_clear.Size = new System.Drawing.Size(75, 23);
            this.bt_clear.TabIndex = 5;
            this.bt_clear.Text = "Clear";
            this.bt_clear.UseVisualStyleBackColor = true;
            this.bt_clear.Click += new System.EventHandler(this.bt_clear_Click);
            // 
            // bt_remove
            // 
            this.bt_remove.Location = new System.Drawing.Point(96, 191);
            this.bt_remove.Name = "bt_remove";
            this.bt_remove.Size = new System.Drawing.Size(75, 23);
            this.bt_remove.TabIndex = 6;
            this.bt_remove.Text = "Remove";
            this.bt_remove.UseVisualStyleBackColor = true;
            this.bt_remove.Click += new System.EventHandler(this.bt_remove_Click);
            // 
            // bt_pilih
            // 
            this.bt_pilih.Location = new System.Drawing.Point(177, 191);
            this.bt_pilih.Name = "bt_pilih";
            this.bt_pilih.Size = new System.Drawing.Size(75, 23);
            this.bt_pilih.TabIndex = 7;
            this.bt_pilih.Text = "Pilih";
            this.bt_pilih.UseVisualStyleBackColor = true;
            this.bt_pilih.Click += new System.EventHandler(this.bt_pilih_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(598, 313);
            this.Controls.Add(this.bt_pilih);
            this.Controls.Add(this.bt_remove);
            this.Controls.Add(this.bt_clear);
            this.Controls.Add(this.tb_makan);
            this.Controls.Add(this.bt_add);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.lb_makanan);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lb_makanan;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_add;
        private System.Windows.Forms.TextBox tb_makan;
        private System.Windows.Forms.Button bt_clear;
        private System.Windows.Forms.Button bt_remove;
        private System.Windows.Forms.Button bt_pilih;
    }
}

