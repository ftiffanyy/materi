﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week_5
{
    internal class player
    {
        //attributes
        private string playerName;
        private string playerNum;
        private string playerPos;

        //contructor -- dipanggil setiap class nya dibuat
        public player(string _playerName, string _playerPos, string _playerNum)
        {
            playerName = _playerName;
            playerNum = _playerNum;
            playerPos = _playerPos;
        }

        //getter
        public string getPlayerName() { return playerName; }
        public string getPlayerNum() {  return playerNum; }
        public string getPlayerPos() {  return playerPos; }

        //setter
        public void setPlayerName(string playerName) { this.playerName = playerName; }
        public void setPlayerNum(string playerNum) { this.playerNum = playerNum; }
        public void setPlayerPos(string playerPos) { this.playerPos = playerPos; }
    }
}
