﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_5
{
    public partial class Form1 : Form
    {
        List<team> teams;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            teams = new List<team>();
            List<player> players = new List<player>()
            {
                new player("Edwin", "GK", "01"),
                new player("Christian", "DF", "02"),
                new player("Keenan", "FW", "03")
            };
            teams.Add(new team("UC Ceria", "Indonesia", "Surabaya", players));
            players = new List<player>()
            {
                new player("Kevin", "GK", "01"),
                new player("Jevon", "DF", "02"),
                new player("Valen", "FW", "03")
            };
            teams.Add(new team("AD Keren", "Indonesia", "Surabaya", players));
        }

        private void bt_show_Click(object sender, EventArgs e)
        {
            foreach(team team in teams)
            {
                string output = team.getTeamName() + " is a " + team.getTeamCountry() + " team with " + team.getPlayerList().Count().ToString() +  " players";
                MessageBox.Show(output);
            }
        }
    }
}
