﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_5
{
    internal class team
    {
        //attributes
        private string teamName;
        private string teamCountry;
        private string teamCity;
        private List<player> playerList;

        //constructor
        public team(string teamName, string teamCountry, string teamCity, List<player> playerList)
        {
            this.teamName = teamName;
            this.teamCountry = teamCountry;
            this.teamCity = teamCity;
            this.playerList = playerList;
        }

        //getter
        public string getTeamName() { return teamName; }
        public string getTeamCountry() {  return teamCountry; }
        public string getTeamCity() {  return teamCity; }
        public List<player> getPlayerList() {  return playerList; }
        
        //setter
        public void getTeamName(string _teamName) { teamName = _teamName; }
        public void setTeamCountry(string _teamCountry) {  teamCountry = _teamCountry; }
        public void setTeamCity(string _teamCity) { teamCity = _teamCity; }
        public void setPlayerList(List<player> _playerList) {  playerList = _playerList; }

        public void addPlayer(player player)
        {
            bool kembar = false;
            foreach(player x in playerList)
            {
                if(x.getPlayerNum() == player.getPlayerNum())
                {
                    kembar = true;
                    break;
                }
            }
            if(kembar)
            {
                MessageBox.Show("NOMOR E KEMBAR");
            }
            else
            {
                playerList.Add(player);
            }
        }
    }
}
