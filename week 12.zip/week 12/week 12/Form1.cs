﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dt;
        string query;
        DataTable dtnim;
        int index;

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server =localhost;" + "uid =student;" + "pwd=isbmantap;" + "database=premier_league");
            dt = new DataTable();
            query = "select * from student";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dt);
            dgv.DataSource = dt;
            dtnim = new DataTable();
        }

        private void bt_insert_Click(object sender, EventArgs e)
        {
            query = "select student.student_nim from student";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            dtnim.Rows.Clear();
            sqlDataAdapter.Fill(dtnim);
            bool yn = false;
            string birthday = DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day;
            if (dtnim.Rows.Count > 0)
            {
                for (int i = 0; i < dtnim.Rows.Count; i++)
                {
                    if (tb_nim.Text == dtnim.Rows[i][0].ToString())
                    {
                        yn = false; break;
                    }
                    else
                    {
                        yn = true;
                    }
                }
                if (yn)
                {
                    //cara 2
                    query = $"insert into student values (@id, @name, @birthday, @nim)";
                    sqlCommand.CommandText = query;
                    sqlCommand.Parameters.AddWithValue("@id", tb_id.Text);
                    sqlCommand.Parameters.AddWithValue("@name", tb_nama.Text);
                    sqlCommand.Parameters.AddWithValue("@birthday", birthday);
                    sqlCommand.Parameters.AddWithValue("@nim", tb_nim.Text);
                    sqlConnect.Open();
                    sqlCommand.ExecuteNonQuery();
                    sqlConnect.Close();
                    query = "select * from student";
                    sqlCommand = new MySqlCommand(query, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    dt.Rows.Clear();
                    sqlDataAdapter.Fill(dt);
                }
            }
            else
            {
                //cara 1
                query = $"insert into student values ('{tb_id.Text}', '{tb_nama.Text}', '2024-05-15', '{tb_nim.Text}')";
                sqlConnect.Open();
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlCommand.ExecuteNonQuery();
                sqlConnect.Close();
                query = "select * from student";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dt.Rows.Clear();
                sqlDataAdapter.Fill(dt);
            }
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
            tb_idupdate.Text = dt.Rows[index][0].ToString();
            tb_namaupdate.Text = dt.Rows[index][1].ToString();
            tb_nimupdate.Text = dt.Rows[index][3].ToString();

        }

        private void bt_update_Click(object sender, EventArgs e)
        {
            query = $"update student set student.student_name = '{tb_namaupdate.Text}', student.student_nim = '{tb_nimupdate.Text}' where student.id_student = {tb_idupdate.Text}";
            sqlConnect.Open();
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlCommand.ExecuteNonQuery();
            sqlConnect.Close();
            query = "select * from student";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            dt.Rows.Clear();
            sqlDataAdapter.Fill(dt);
        }
    }
}
