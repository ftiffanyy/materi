﻿namespace week_12
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.bt_insert = new System.Windows.Forms.Button();
            this.tb_id = new System.Windows.Forms.TextBox();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.tb_nim = new System.Windows.Forms.TextBox();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.tb_nimupdate = new System.Windows.Forms.TextBox();
            this.tb_namaupdate = new System.Windows.Forms.TextBox();
            this.tb_idupdate = new System.Windows.Forms.TextBox();
            this.bt_update = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(100, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(56, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nama :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(80, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 31);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nim :";
            // 
            // bt_insert
            // 
            this.bt_insert.Location = new System.Drawing.Point(176, 268);
            this.bt_insert.Name = "bt_insert";
            this.bt_insert.Size = new System.Drawing.Size(123, 49);
            this.bt_insert.TabIndex = 3;
            this.bt_insert.Text = "INSERT";
            this.bt_insert.UseVisualStyleBackColor = true;
            this.bt_insert.Click += new System.EventHandler(this.bt_insert_Click);
            // 
            // tb_id
            // 
            this.tb_id.Location = new System.Drawing.Point(176, 79);
            this.tb_id.Name = "tb_id";
            this.tb_id.Size = new System.Drawing.Size(147, 31);
            this.tb_id.TabIndex = 4;
            // 
            // tb_nama
            // 
            this.tb_nama.Location = new System.Drawing.Point(176, 137);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(147, 31);
            this.tb_nama.TabIndex = 5;
            // 
            // tb_nim
            // 
            this.tb_nim.Location = new System.Drawing.Point(176, 198);
            this.tb_nim.Name = "tb_nim";
            this.tb_nim.Size = new System.Drawing.Size(147, 31);
            this.tb_nim.TabIndex = 6;
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.AllowUserToResizeColumns = false;
            this.dgv.AllowUserToResizeRows = false;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv.Location = new System.Drawing.Point(466, 42);
            this.dgv.MultiSelect = false;
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersVisible = false;
            this.dgv.RowHeadersWidth = 82;
            this.dgv.RowTemplate.Height = 33;
            this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv.Size = new System.Drawing.Size(797, 731);
            this.dgv.TabIndex = 7;
            this.dgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellClick);
            // 
            // tb_nimupdate
            // 
            this.tb_nimupdate.Location = new System.Drawing.Point(176, 542);
            this.tb_nimupdate.Name = "tb_nimupdate";
            this.tb_nimupdate.Size = new System.Drawing.Size(147, 31);
            this.tb_nimupdate.TabIndex = 14;
            // 
            // tb_namaupdate
            // 
            this.tb_namaupdate.Location = new System.Drawing.Point(176, 481);
            this.tb_namaupdate.Name = "tb_namaupdate";
            this.tb_namaupdate.Size = new System.Drawing.Size(147, 31);
            this.tb_namaupdate.TabIndex = 13;
            // 
            // tb_idupdate
            // 
            this.tb_idupdate.Enabled = false;
            this.tb_idupdate.Location = new System.Drawing.Point(176, 423);
            this.tb_idupdate.Name = "tb_idupdate";
            this.tb_idupdate.Size = new System.Drawing.Size(147, 31);
            this.tb_idupdate.TabIndex = 12;
            // 
            // bt_update
            // 
            this.bt_update.Location = new System.Drawing.Point(176, 612);
            this.bt_update.Name = "bt_update";
            this.bt_update.Size = new System.Drawing.Size(123, 49);
            this.bt_update.TabIndex = 11;
            this.bt_update.Text = "UPDATE";
            this.bt_update.UseVisualStyleBackColor = true;
            this.bt_update.Click += new System.EventHandler(this.bt_update_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(80, 542);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 31);
            this.label4.TabIndex = 10;
            this.label4.Text = "Nim :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(56, 478);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 31);
            this.label5.TabIndex = 9;
            this.label5.Text = "Nama :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(100, 420);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 31);
            this.label6.TabIndex = 8;
            this.label6.Text = "ID :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1306, 822);
            this.Controls.Add(this.tb_nimupdate);
            this.Controls.Add(this.tb_namaupdate);
            this.Controls.Add(this.tb_idupdate);
            this.Controls.Add(this.bt_update);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.tb_nim);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.tb_id);
            this.Controls.Add(this.bt_insert);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bt_insert;
        private System.Windows.Forms.TextBox tb_id;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.TextBox tb_nim;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.TextBox tb_nimupdate;
        private System.Windows.Forms.TextBox tb_namaupdate;
        private System.Windows.Forms.TextBox tb_idupdate;
        private System.Windows.Forms.Button bt_update;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

