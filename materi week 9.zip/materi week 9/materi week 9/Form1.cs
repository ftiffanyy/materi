﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; //jgn lupa 

namespace materi_week_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter SqlDataAdapter;
        private void bt_login_Click(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection($"server = 10.10.10.136; uid={tb_user.Text} ;pwd= {tb_pass.Text} ;database={tb_database.Text}");
            sqlConnect.Open();
            MessageBox.Show("yay");
            sqlConnect.Close();
            string sqlquery = "select * from player";
            DataTable dt = new DataTable();
            sqlCommand = new MySqlCommand(sqlquery, sqlConnect);
            SqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            SqlDataAdapter.Fill(dt);
            dgv.DataSource = dt;
        }

        private void bt_refresh_Click(object sender, EventArgs e)
        {
            string sqlquery = "select * from mahasiswa";
            DataTable dtmhs = new DataTable();
            sqlCommand = new MySqlCommand(sqlquery, sqlConnect);
            SqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            SqlDataAdapter.Fill(dtmhs);
            dgvmhs.DataSource = dtmhs;
        }

        private void bt_submit_Click(object sender, EventArgs e)
        {
            string sqlquery = $"insert into mahasiswa (nim_mahasiswa, nama_mahasiswa, kota_asal) values ('{tb_nim.Text}', '{tb_nama.Text}', '{tb_kota.Text}')";
            sqlCommand = new MySqlCommand(sqlquery,sqlConnect);
            sqlConnect.Open();
            sqlCommand.ExecuteNonQuery();
            sqlConnect.Close();
        }
    }
}
